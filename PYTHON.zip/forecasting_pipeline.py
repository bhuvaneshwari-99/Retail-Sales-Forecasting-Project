"""
Retail Sales Forecasting Pipeline
==================================
Loads the daily total-revenue series from retail_sales.db, engineers
calendar/lag features, fits baseline + SARIMA + XGBoost models, and
compares them on a held-out test period using MAE / RMSE / MAPE.

Run: python3 forecasting_pipeline.py
Outputs: reports/figures/*.png, printed evaluation table
"""

import sqlite3
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

DB_PATH = "/mnt/user-data/outputs/retail_sales.db"
FIG_DIR = "/home/claude/retail_project/reports/figures"
TEST_DAYS = 60  # hold out the last 60 days for evaluation

pd.set_option("display.width", 120)

# ------------------------------------------------------------------
# 1. LOAD DATA
# ------------------------------------------------------------------
def load_daily_series(db_path=DB_PATH):
    conn = sqlite3.connect(db_path)
    df = pd.read_sql(
        """
        SELECT date,
               SUM(revenue) AS revenue,
               MAX(promo_flag) AS promo_flag,
               MAX(holiday_flag) AS holiday_flag
        FROM sales
        GROUP BY date
        ORDER BY date
        """,
        conn,
        parse_dates=["date"],
    )
    conn.close()
    df = df.set_index("date").asfreq("D")
    df["revenue"] = df["revenue"].interpolate()  # guard against any gaps
    df[["promo_flag", "holiday_flag"]] = df[["promo_flag", "holiday_flag"]].fillna(0)
    return df


# ------------------------------------------------------------------
# 2. FEATURE ENGINEERING
# ------------------------------------------------------------------
def add_features(df):
    out = df.copy()
    out["day_of_week"] = out.index.dayofweek
    out["is_weekend"] = (out["day_of_week"] >= 5).astype(int)
    out["month"] = out.index.month
    out["lag_1"] = out["revenue"].shift(1)
    out["lag_7"] = out["revenue"].shift(7)
    out["lag_14"] = out["revenue"].shift(14)
    out["rolling_mean_7"] = out["revenue"].shift(1).rolling(7).mean()
    out["rolling_mean_28"] = out["revenue"].shift(1).rolling(28).mean()
    out["rolling_std_7"] = out["revenue"].shift(1).rolling(7).std()
    return out


# ------------------------------------------------------------------
# 3. METRICS
# ------------------------------------------------------------------
def mae(y_true, y_pred):
    return float(np.mean(np.abs(y_true - y_pred)))

def rmse(y_true, y_pred):
    return float(np.sqrt(np.mean((y_true - y_pred) ** 2)))

def mape(y_true, y_pred):
    return float(np.mean(np.abs((y_true - y_pred) / y_true)) * 100)

def evaluate(name, y_true, y_pred, results):
    results.append({
        "model": name,
        "MAE": round(mae(y_true, y_pred), 2),
        "RMSE": round(rmse(y_true, y_pred), 2),
        "MAPE (%)": round(mape(y_true, y_pred), 2),
    })


# ------------------------------------------------------------------
# 4. EDA PLOTS
# ------------------------------------------------------------------
def make_eda_plots(df):
    # Daily revenue over time
    fig, ax = plt.subplots(figsize=(12, 4))
    df["revenue"].plot(ax=ax, linewidth=0.8)
    ax.set_title("Daily Total Revenue (2023-2024)")
    ax.set_ylabel("Revenue ($)")
    fig.tight_layout()
    fig.savefig(f"{FIG_DIR}/01_daily_revenue.png", dpi=110)
    plt.close(fig)

    # Monthly revenue
    monthly = df["revenue"].resample("ME").sum()
    fig, ax = plt.subplots(figsize=(12, 4))
    monthly.plot(ax=ax, kind="bar")
    ax.set_title("Monthly Total Revenue")
    ax.set_ylabel("Revenue ($)")
    ax.set_xticklabels([d.strftime("%Y-%m") for d in monthly.index], rotation=90)
    fig.tight_layout()
    fig.savefig(f"{FIG_DIR}/02_monthly_revenue.png", dpi=110)
    plt.close(fig)

    # Seasonal decomposition
    from statsmodels.tsa.seasonal import seasonal_decompose
    decomp = seasonal_decompose(df["revenue"], model="additive", period=365)
    fig = decomp.plot()
    fig.set_size_inches(12, 8)
    fig.tight_layout()
    fig.savefig(f"{FIG_DIR}/03_seasonal_decompose.png", dpi=110)
    plt.close(fig)

    # ADF stationarity test
    from statsmodels.tsa.stattools import adfuller
    adf_stat, adf_p, *_ = adfuller(df["revenue"].dropna())
    print(f"ADF test: statistic={adf_stat:.3f}, p-value={adf_p:.4f}"
          f" -> {'stationary' if adf_p < 0.05 else 'NOT stationary (has trend/seasonality)'}")


# ------------------------------------------------------------------
# 5. BASELINE MODELS
# ------------------------------------------------------------------
def run_baselines(train, test, results):
    full = pd.concat([train, test])
    preds = {}

    # Naive: yesterday's value
    naive_pred = full["revenue"].shift(1).loc[test.index]
    preds["naive"] = naive_pred
    evaluate("Baseline: Naive (t-1)", test["revenue"], naive_pred, results)

    # Seasonal naive: same day last week
    seasonal_naive_pred = full["revenue"].shift(7).loc[test.index]
    preds["seasonal_naive"] = seasonal_naive_pred
    evaluate("Baseline: Seasonal Naive (t-7)", test["revenue"], seasonal_naive_pred, results)

    # Moving average: trailing 7-day mean
    ma_pred = full["revenue"].shift(1).rolling(7).mean().loc[test.index]
    preds["moving_avg"] = ma_pred
    evaluate("Baseline: 7-day Moving Average", test["revenue"], ma_pred, results)

    return preds


# ------------------------------------------------------------------
# 6. SARIMA MODEL
# ------------------------------------------------------------------
def run_sarima(train, test, results):
    from statsmodels.tsa.statespace.sarimax import SARIMAX

    # weekly seasonality (m=7); (p,d,q) kept small for speed on daily data
    model = SARIMAX(
        train["revenue"],
        order=(1, 1, 1),
        seasonal_order=(1, 1, 1, 7),
        enforce_stationarity=False,
        enforce_invertibility=False,
    )
    fitted = model.fit(disp=False)
    forecast = fitted.forecast(steps=len(test))
    forecast.index = test.index
    evaluate("SARIMA(1,1,1)(1,1,1,7)", test["revenue"], forecast, results)
    return forecast


# ------------------------------------------------------------------
# 7. XGBOOST MODEL (uses lag/rolling/calendar features)
# ------------------------------------------------------------------
def run_xgboost(feat_df, train_idx, test_idx, results):
    from xgboost import XGBRegressor

    feature_cols = ["day_of_week", "is_weekend", "month", "promo_flag", "holiday_flag",
                     "lag_1", "lag_7", "lag_14", "rolling_mean_7", "rolling_mean_28", "rolling_std_7"]
    data = feat_df.dropna(subset=feature_cols + ["revenue"])

    train_data = data.loc[data.index.intersection(train_idx)]
    test_data = data.loc[data.index.intersection(test_idx)]

    X_train, y_train = train_data[feature_cols], train_data["revenue"]
    X_test, y_test = test_data[feature_cols], test_data["revenue"]

    model = XGBRegressor(
        n_estimators=300, max_depth=4, learning_rate=0.05,
        subsample=0.8, colsample_bytree=0.8, random_state=42
    )
    model.fit(X_train, y_train)
    pred = pd.Series(model.predict(X_test), index=test_data.index)

    evaluate("XGBoost (lag+calendar features)", y_test, pred, results)

    # feature importance
    importance = pd.Series(model.feature_importances_, index=feature_cols).sort_values(ascending=False)
    print("\nXGBoost feature importance:")
    print(importance.round(3).to_string())

    return pred, y_test


# ------------------------------------------------------------------
# 8. MAIN
# ------------------------------------------------------------------
def main():
    print("Loading data...")
    df = load_daily_series()
    print(f"Loaded {len(df)} days: {df.index.min().date()} to {df.index.max().date()}")

    print("\nRunning EDA...")
    make_eda_plots(df)

    feat_df = add_features(df)

    split_date = df.index.max() - pd.Timedelta(days=TEST_DAYS - 1)
    train = df.loc[df.index < split_date]
    test = df.loc[df.index >= split_date]
    print(f"\nTrain: {train.index.min().date()} to {train.index.max().date()} ({len(train)} days)")
    print(f"Test:  {test.index.min().date()} to {test.index.max().date()} ({len(test)} days)")

    results = []
    print("\nRunning baseline models...")
    baseline_preds = run_baselines(train, test, results)

    print("Running SARIMA (this may take ~30-60s)...")
    sarima_pred = run_sarima(train, test, results)

    print("Running XGBoost...")
    xgb_pred, xgb_y_test = run_xgboost(feat_df, train.index, test.index, results)

    # ---- final comparison table ----
    results_df = pd.DataFrame(results).sort_values("MAPE (%)")
    print("\n" + "=" * 60)
    print("MODEL COMPARISON (lower is better)")
    print("=" * 60)
    print(results_df.to_string(index=False))
    results_df.to_csv("/mnt/user-data/outputs/model_comparison.csv", index=False)

    # ---- plot actual vs forecasts on test period ----
    fig, ax = plt.subplots(figsize=(12, 5))
    ax.plot(test.index, test["revenue"], label="Actual", color="black", linewidth=1.5)
    ax.plot(test.index, sarima_pred, label="SARIMA", linestyle="--")
    ax.plot(xgb_y_test.index, xgb_pred, label="XGBoost", linestyle="--")
    ax.plot(test.index, baseline_preds["seasonal_naive"], label="Seasonal Naive", linestyle=":", alpha=0.7)
    ax.set_title(f"Actual vs Forecast — Last {TEST_DAYS} Days")
    ax.set_ylabel("Daily Revenue ($)")
    ax.legend()
    fig.tight_layout()
    fig.savefig(f"{FIG_DIR}/04_forecast_comparison.png", dpi=110)
    plt.close(fig)

    print(f"\nFigures saved to {FIG_DIR}/")
    print("Model comparison saved to /mnt/user-data/outputs/model_comparison.csv")


if __name__ == "__main__":
    main()
